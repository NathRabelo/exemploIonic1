﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CorrecaoListaPresen01.controle;
using CorrecaoListaPresen01.model;

namespace CorrecaoListaPresen01.visoes
{
    public partial class FrmDadosSalarios : Form
    {
        public FrmDadosSalarios()
        {
            InitializeComponent();
        }

        private void FrmDadosSalarios_Load(object sender, EventArgs e)
        {
            //PREENCHER OS COMBOBOS AUTOMÁTICAMENTE ASSIM QUE O FORMULÁRIO É CARREGADO
            cbbFuncionariosSal.Enabled = false;
            //O que será exibido no combobox para o usuário
            cbbFuncionariosSal.DisplayMember = "nome";
            //Qual será o valor daquela seleção do combobox
            cbbFuncionariosSal.ValueMember = "id";
            //Preencher o combobox
            cbbFuncionariosSal.DataSource = DadosBD.DadosComboBox();
            cbbFuncionariosSal.SelectedIndex = 0;
            cbbOpcoes.SelectedIndex = 0;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
           
        }

        private void cbbOpcoes_SelectedIndexChanged(object sender, EventArgs e)
       {
            lstDados.Items.Clear();

            if (cbbOpcoes.SelectedIndex == 1)
            {
                MessageBox.Show("11111");
                ""
                //DADOS DE TODOS OS FUNCIONÁRIOS
                cbbFuncionariosSal.Enabled = false;
                //Variável auxiliar que irá armazenar todo conteúdo que será exibido na tabela

                List<string[]> dados = DadosBD.DadosSalario();
               // List<string[]> dados2 = DadosBD.DadosFuncionarios();

                //Como inserir dados no ListView
                ListViewItem item;
               // ListViewItem item2;
                for (int i = 0; i < dados.Count; i++)
                {
                    item = new ListViewItem(dados[i]);
                 //   item2 = new ListViewItem(dados2[i]);
                    lstDados.Items.Add(item);
                   // lstDados.Items.Add(item2);

                }
                            }

            if (cbbOpcoes.SelectedIndex == 2)
            {
                //DADOS SALARIO DE UM FUNCIONÁRIO ESPECÍFICO
                cbbFuncionariosSal.Enabled = true;
                cbbFuncionariosSal.SelectedIndex = 0;

            }
            else
            {
                cbbFuncionariosSal.Enabled = false;
                cbbFuncionariosSal.SelectedIndex = 0;
            }
        }

        private void cbbFuncionariosSal_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] dados = DadosBD.DadosSalario((int)cbbFuncionariosSal.SelectedValue);
            ListViewItem item;

            item = new ListViewItem(dados);
            lstDados.Items.Add(item);
        }
    }
}
