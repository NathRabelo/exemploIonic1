﻿using System;
using System.Windows.Forms;
using CorrecaoListaPresen01.model;
using CorrecaoListaPresen01.controle;

namespace CorrecaoListaPresen01.visoes
{
    public partial class FrmCadSalario : Form
    {
        public FrmCadSalario()
        {
            InitializeComponent();
        }

        private void FrmCadSalario_Load(object sender, EventArgs e)
        {
            //O que será exibido no combobox para o usuário
            cbbFuncionarios.DisplayMember = "nome";
            //Qual será o valor daquela seleção do combobox
            cbbFuncionarios.ValueMember = "id";
            //Preencher o combobox
            cbbFuncionarios.DataSource = DadosBD.DadosComboBox();
        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {
            Salario nomeSal = new Salario(Funcionario.Equals.n);
            DadosBD.CadastroSal((int)cbbFuncionarios.SelectedValue, sal);

            Salario sal = new Salario(Registros.IdSalario(), double.Parse(txtSalbase.Text), double.Parse(txtComissao.Text), dtpData.Text);
            DadosBD.CadastroSal((int)cbbFuncionarios.SelectedValue, sal);
            this.Close();
        }

        private void cbbFuncionarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Id do funcionário: " + cbbFuncionarios.SelectedValue);
        }

        private void dtpData_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
