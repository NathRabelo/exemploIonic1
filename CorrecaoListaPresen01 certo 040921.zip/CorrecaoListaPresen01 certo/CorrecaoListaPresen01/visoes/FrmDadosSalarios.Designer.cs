﻿
namespace CorrecaoListaPresen01.visoes
{
    partial class FrmDadosSalarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstDados = new System.Windows.Forms.ListView();
            this.colId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSalario = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colComissao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSalBrutro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colFgts = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnBuscar = new System.Windows.Forms.Button();
            this.cbbOpcoes = new System.Windows.Forms.ComboBox();
            this.cbbFuncionariosSal = new System.Windows.Forms.ComboBox();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.S = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstDados
            // 
            this.lstDados.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colId,
            this.colNome,
            this.colSalario,
            this.colComissao,
            this.colSalBrutro,
            this.colFgts,
            this.colData});
            this.lstDados.HideSelection = false;
            this.lstDados.Location = new System.Drawing.Point(12, 12);
            this.lstDados.Name = "lstDados";
            this.lstDados.Size = new System.Drawing.Size(897, 298);
            this.lstDados.TabIndex = 0;
            this.lstDados.UseCompatibleStateImageBehavior = false;
            this.lstDados.View = System.Windows.Forms.View.Details;
            // 
            // colId
            // 
            this.colId.Text = "Registro";
            this.colId.Width = 81;
            // 
            // colNome
            // 
            this.colNome.Text = "Nome";
            this.colNome.Width = 219;
            // 
            // colSalario
            // 
            this.colSalario.Text = "Salário base";
            this.colSalario.Width = 111;
            // 
            // colComissao
            // 
            this.colComissao.Text = "Comissão";
            this.colComissao.Width = 107;
            // 
            // colSalBrutro
            // 
            this.colSalBrutro.Text = "Salário Bruto";
            this.colSalBrutro.Width = 134;
            // 
            // colFgts
            // 
            this.colFgts.Text = "FGTS";
            this.colFgts.Width = 96;
            // 
            // colData
            // 
            this.colData.Text = "Data Pagamento";
            this.colData.Width = 152;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(749, 319);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(160, 62);
            this.btnBuscar.TabIndex = 1;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // cbbOpcoes
            // 
            this.cbbOpcoes.FormattingEnabled = true;
            this.cbbOpcoes.Items.AddRange(new object[] {
            "Selecione",
            "Mostrar todos",
            "Mostrar Selecionado"});
            this.cbbOpcoes.Location = new System.Drawing.Point(127, 316);
            this.cbbOpcoes.Name = "cbbOpcoes";
            this.cbbOpcoes.Size = new System.Drawing.Size(219, 37);
            this.cbbOpcoes.TabIndex = 18;
            this.cbbOpcoes.SelectedIndexChanged += new System.EventHandler(this.cbbOpcoes_SelectedIndexChanged);
            // 
            // cbbFuncionariosSal
            // 
            this.cbbFuncionariosSal.Enabled = false;
            this.cbbFuncionariosSal.FormattingEnabled = true;
            this.cbbFuncionariosSal.Location = new System.Drawing.Point(127, 361);
            this.cbbFuncionariosSal.Name = "cbbFuncionariosSal";
            this.cbbFuncionariosSal.Size = new System.Drawing.Size(219, 37);
            this.cbbFuncionariosSal.TabIndex = 17;
            this.cbbFuncionariosSal.SelectedIndexChanged += new System.EventHandler(this.cbbFuncionariosSal_SelectedIndexChanged);
            // 
            // dtpData
            // 
            this.dtpData.CustomFormat = "MM/yyyy";
            this.dtpData.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpData.Location = new System.Drawing.Point(444, 316);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(131, 35);
            this.dtpData.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(377, 319);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 29);
            this.label1.TabIndex = 20;
            this.label1.Text = "Data:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 319);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 29);
            this.label2.TabIndex = 21;
            this.label2.Text = "Opções:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 361);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 29);
            this.label3.TabIndex = 22;
            this.label3.Text = "Funcionário:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(377, 361);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(293, 29);
            this.label4.TabIndex = 23;
            this.label4.Text = "Média salárial do período:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(571, 361);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 29);
            this.label5.TabIndex = 24;
            this.label5.Text = "R$ ";
            // 
            // S
            // 
            this.S.AutoSize = true;
            this.S.Location = new System.Drawing.Point(611, 361);
            this.S.Name = "S";
            this.S.Size = new System.Drawing.Size(58, 29);
            this.S.TabIndex = 25;
            this.S.Text = "0,00";
            // 
            // FrmDadosSalarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 399);
            this.Controls.Add(this.S);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpData);
            this.Controls.Add(this.cbbOpcoes);
            this.Controls.Add(this.cbbFuncionariosSal);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.lstDados);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmDadosSalarios";
            this.Text = "FrmDadosSalarios";
            this.Load += new System.EventHandler(this.FrmDadosSalarios_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstDados;
        private System.Windows.Forms.ColumnHeader colId;
        private System.Windows.Forms.ColumnHeader colNome;
        private System.Windows.Forms.ColumnHeader colSalario;
        private System.Windows.Forms.ColumnHeader colComissao;
        private System.Windows.Forms.ColumnHeader colSalBrutro;
        private System.Windows.Forms.ColumnHeader colFgts;
        private System.Windows.Forms.ColumnHeader colData;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.ComboBox cbbOpcoes;
        private System.Windows.Forms.ComboBox cbbFuncionariosSal;
        private System.Windows.Forms.DateTimePicker dtpData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label S;
    }
}