﻿using System;
using System.Windows.Forms;
using CorrecaoListaPresen01.controle;
using CorrecaoListaPresen01.model;

namespace CorrecaoListaPresen01.visoes
{
    public partial class FrmCadFuncionario : Form
    {
        public FrmCadFuncionario()
        {
            InitializeComponent();
        }
        private void btnCadastro_Click(object sender, EventArgs e)
        {            
            Funcionario func = new Funcionario(Registros.IdFuncionario(), txtNome.Text, mtbCpf.Text, mtbRg.Text);
            DadosBD.Cadastro(func);
            this.Close();
        }
    }
}
