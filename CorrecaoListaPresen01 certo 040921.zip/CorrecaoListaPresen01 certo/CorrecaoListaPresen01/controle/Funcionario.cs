﻿using System;
using System.Collections.Generic;

namespace CorrecaoListaPresen01.controle
{
    class Funcionario
    {
        /*
         * Trabalhando com properties que nada mais é que as propriedades dos atributos
         * Com ela eu posso definir de maneira mais fácil o get como público caso queira permitir a exibição deles
         * e o set como private para que ele não posso ser alterado em nenhum outro lugar que não seja na classe que ele pertence
         */
        public int NumRegistro { get; private set; }
        public string Nome { get; private set; }
        public string Cpf { get; private set; }
        public string Rg { get; private set; }
        public List<Salario> Salarios { get; private set; }


        public Funcionario(int registro, string nome, string cpf, string rg)
        {
            this.NumRegistro = registro;
            this.Nome = nome;
            this.Cpf = cpf;
            this.Rg = rg;
            this.Salarios = new List<Salario>();
        }
        public string[] Dados()
        {
            string[] dados = { 
                this.NumRegistro.ToString(),
                this.Nome,
                this.Cpf,
                this.Rg
            };
            return dados;
        }
    }
}
