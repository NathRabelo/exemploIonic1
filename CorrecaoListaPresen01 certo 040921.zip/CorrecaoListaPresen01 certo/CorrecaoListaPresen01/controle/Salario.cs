﻿using System;
namespace CorrecaoListaPresen01.controle
{
    class Salario
    {
        public int Id { get; private set; }
        public double SalBase { get; private set; }
        public double Comissao { get; private set; }
        public double Fgts { get; private set; }
        public string Data { get; private set; }


        public Salario(int id, double salario, double comissao, string data)
        {
            this.Id = id;
            this.SalBase = salario;
            this.Comissao = comissao;
            this.Data = data;
            CalcFgts();
        }
        public string[] SalarioExibicao()
        {
            string[] dados = {
                this.Id.ToString(),
                this.SalBase.ToString(),
                this.Comissao.ToString(),
                this.Data,
                this.Fgts.ToString()  
            };
            return dados;
        }
        public double SalarioBruto()
        {
            return this.SalBase + this.Comissao;
        }

        private void CalcFgts()
        {
            double salTotal = SalarioBruto();
            if (salTotal > 0.00 && salTotal <= 2000.00) //FAIXA ISENTO
            {
                this.Fgts = 0.00;
            }
            else if (salTotal > 2000.00 && salTotal <= 3000.00) // FAIXA 8%
            {
                this.Fgts = (salTotal - 2000.00) * 0.08;
            }
            else if (salTotal > 3000.00 && salTotal <= 4500.00) //FAIXA 18%
            {
                this.Fgts = (salTotal - 3000.00) * 0.18 + 80.00;
            }
            else //FAIXA 28%
            {
                this.Fgts = (salTotal - 4500.00) * 0.28 + 80.00 + 270.00;
            }
        }
    }
}
