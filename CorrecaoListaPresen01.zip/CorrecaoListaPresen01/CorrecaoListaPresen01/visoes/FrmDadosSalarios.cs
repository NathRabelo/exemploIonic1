﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CorrecaoListaPresen01.controle;

namespace CorrecaoListaPresen01.visoes
{
    public partial class FrmDadosSalarios : Form
    {
        public FrmDadosSalarios()
        {
            InitializeComponent();
        }

        private void FrmDadosSalarios_Load(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //Salario exibirSalario = new Salario();


            if(cbbOpcoes.SelectedIndex == 1){
                cbbFuncionariosSal.Enabled = false;
                List<string[]> dados = Salario.();
            }
            else if(cbbOpcoes.SelectedIndex == 2){
                string[] dados = DadosBD.DadosFuncionarios((int)cbbSa.SelectedValue);
                ListViewItem item;

                item = new ListViewItem(dados);
                lstDados.Items.Add(item);
            }
            //apenas func selecionado
            

        }
    }
}
