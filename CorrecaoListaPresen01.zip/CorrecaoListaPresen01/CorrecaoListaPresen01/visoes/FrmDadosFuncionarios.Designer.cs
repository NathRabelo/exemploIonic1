﻿
namespace CorrecaoListaPresen01.visoes
{
    partial class FrmDadosFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstDados = new System.Windows.Forms.ListView();
            this.colID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCpf = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRg = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cbbFuncionarios = new System.Windows.Forms.ComboBox();
            this.cbbOpcoes = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstDados
            // 
            this.lstDados.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colID,
            this.colNome,
            this.colCpf,
            this.colRg});
            this.lstDados.HideSelection = false;
            this.lstDados.Location = new System.Drawing.Point(11, 12);
            this.lstDados.MultiSelect = false;
            this.lstDados.Name = "lstDados";
            this.lstDados.Size = new System.Drawing.Size(771, 324);
            this.lstDados.TabIndex = 0;
            this.lstDados.UseCompatibleStateImageBehavior = false;
            this.lstDados.View = System.Windows.Forms.View.Details;
            // 
            // colID
            // 
            this.colID.Text = "Registro";
            this.colID.Width = 95;
            // 
            // colNome
            // 
            this.colNome.Text = "Nome";
            this.colNome.Width = 305;
            // 
            // colCpf
            // 
            this.colCpf.Text = "CPF";
            this.colCpf.Width = 172;
            // 
            // colRg
            // 
            this.colRg.Text = "RG";
            this.colRg.Width = 191;
            // 
            // cbbFuncionarios
            // 
            this.cbbFuncionarios.FormattingEnabled = true;
            this.cbbFuncionarios.Location = new System.Drawing.Point(563, 342);
            this.cbbFuncionarios.Name = "cbbFuncionarios";
            this.cbbFuncionarios.Size = new System.Drawing.Size(219, 28);
            this.cbbFuncionarios.TabIndex = 15;
            this.cbbFuncionarios.SelectedIndexChanged += new System.EventHandler(this.cbbFuncionarios_SelectedIndexChanged);
            // 
            // cbbOpcoes
            // 
            this.cbbOpcoes.FormattingEnabled = true;
            this.cbbOpcoes.Items.AddRange(new object[] {
            "Selecione",
            "Mostrar todos",
            "Mostrar Selecionado"});
            this.cbbOpcoes.Location = new System.Drawing.Point(276, 342);
            this.cbbOpcoes.Name = "cbbOpcoes";
            this.cbbOpcoes.Size = new System.Drawing.Size(179, 28);
            this.cbbOpcoes.TabIndex = 16;
            this.cbbOpcoes.SelectedIndexChanged += new System.EventHandler(this.cbbOpcoes_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(202, 345);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Opções:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(461, 349);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "Funcionário:";
            // 
            // FrmDadosFuncionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 378);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbbOpcoes);
            this.Controls.Add(this.cbbFuncionarios);
            this.Controls.Add(this.lstDados);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmDadosFuncionarios";
            this.Text = "DadosFuncionarios";
            this.Load += new System.EventHandler(this.FrmDadosFuncionarios_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstDados;
        private System.Windows.Forms.ColumnHeader colID;
        private System.Windows.Forms.ColumnHeader colNome;
        private System.Windows.Forms.ColumnHeader colCpf;
        private System.Windows.Forms.ColumnHeader colRg;
        private System.Windows.Forms.ComboBox cbbFuncionarios;
        private System.Windows.Forms.ComboBox cbbOpcoes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}