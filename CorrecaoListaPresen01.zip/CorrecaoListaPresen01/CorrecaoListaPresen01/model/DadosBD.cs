﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CorrecaoListaPresen01.controle; //Dando acesso à esse pacote

namespace CorrecaoListaPresen01.model
{
    static class DadosBD
    {
        public static List<Funcionario> Funcionarios = new List<Funcionario>();
        //Cadastro Funcionário
        /*
         * Pegamos o objeto Funcionario já criado
         * e salvamos ele na Lista onde todos eles ficaram salvos
         */
        public static void Cadastro(Funcionario func)
        {
            Funcionarios.Add(func);
        }

        //Cadastro Salário
        /*
         * Mesma ideia do cadastro de funcionários
         * Mas fazemos um busca pelo id dele para salvar no lugar certo
         */
        public static void Cadastro(int id, Salario sal)
        {
            for (int i = 0; i < Funcionarios.Count; i++)
            {
                if (Funcionarios[i].NumRegistro.Equals(id))
                {
                    Funcionarios[i].Salarios.Add(sal);
                    break;
                }
            }
        }


        //Dados para preencher o combobox funcionários de modo dinámico
        //Será exibido o nome do funcionário
        //Mas o valor será seu id
        public static List<object> DadosComboBox()
        {
            List<object> dados = new List<object>();
            dados.Add(new { id = 0, nome = "Selecione" });
            for (int i = 0; i < Funcionarios.Count; i++)
            {
                dados.Add(new { 
                                id = Funcionarios[i].NumRegistro,
                                nome = Funcionarios[i].Nome
                        });
            }
            return dados;
        }

        //Dados para o ListView da tela de dados dos funcionários
        //Para todos eles
        public static List<string[]> DadosFuncionarios()
        {
            List<string[]> dados = new List<string[]>();
            for (int i = 0; i < Funcionarios.Count; i++)
            {
                dados.Add(Funcionarios[i].Dados());
            }
            return dados;
        }

        //Para um selecionado
        public static string[] DadosFuncionarios(int id)
        {
            string[] dados = new string[4];
            for (int i = 0; i < Funcionarios.Count; i++)
            {
                if (Funcionarios[i].NumRegistro.Equals(id))
                {
                    dados = Funcionarios[i].Dados();
                    break;
                }
            }
            return dados;
        }
    }
}
