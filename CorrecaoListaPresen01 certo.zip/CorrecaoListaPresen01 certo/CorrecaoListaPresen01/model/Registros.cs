﻿using System;
using System.Threading.Tasks;

namespace CorrecaoListaPresen01.model
{
    static class Registros
    {
        public static int Func { get; private set; }
        public static int Sal { get; private set; }

        public static int IdFuncionario()
        {
            Func++;
            return Func;
        }

        public static int IdSalario()
        {
            Sal++;
            return Sal;
        }
    }
}
