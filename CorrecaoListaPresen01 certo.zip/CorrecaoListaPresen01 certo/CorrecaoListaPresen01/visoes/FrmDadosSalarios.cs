﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CorrecaoListaPresen01.controle;
using CorrecaoListaPresen01.model;

namespace CorrecaoListaPresen01.visoes
{
    public partial class FrmDadosSalarios : Form
    {
        public FrmDadosSalarios()
        {
            InitializeComponent();
        }

        private void FrmDadosSalarios_Load(object sender, EventArgs e)
        {
            //PREENCHER OS COMBOBOS AUTOMÁTICAMENTE ASSIM QUE O FORMULÁRIO É CARREGADO
            cbbFuncionariosSal.Enabled = false;
            //O que será exibido no combobox para o usuário
            cbbFuncionariosSal.DisplayMember = "nome";
            //Qual será o valor daquela seleção do combobox
            cbbFuncionariosSal.ValueMember = "id";
            //Preencher o combobox
            cbbFuncionariosSal.DataSource = DadosBD.DadosComboBox();
            cbbFuncionariosSal.SelectedIndex = 0;
            cbbOpcoes.SelectedIndex = 0;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //Salario exibirSalario = new Salario();

             if(cbbOpcoes.SelectedIndex == 1){
                
                //DADOS DE TODOS OS FUNCIONÁRIOS
                cbbFuncionariosSal.Enabled = false;
                //Variável auxiliar que irá armazenar todo conteúdo que será exibido na tabela
             
                List<string[]> dados = DadosBD.CadastroSal<>;
                //ListView
                /*
                 * Um componente usado para organizar os dados em tabelas
                 * Deixando tudo mais organizado e de fácil entendimento
                 * Prefixo para ele lstNomeDele
                 * Para criar as colunas usa-se a propriedade Columns
                 * Para mostrar as colunas criada deixe a propriedade view como details
                 */

                //Como inserir dados no ListView
                ListViewItem item;
                for (int i = 0; i < dados.Count; i++)
                {
                    item = new ListViewItem(dados[i]);
                    lstDados.Items.Add(item);
                    /*
                     * Os itens devem vir em um vetor de string
                     * Cada posição do vetor é uma coluna do ListView
                     * Eles devem estar na mesma ordem de criação das colunas do ListView
                     * A montagem desse vetor está vindo da classe Funcionario da pasta de controle
                     * A montagem dessa lista de vetores está vindo da classe DadosBD
                     */
              
            }
            else if(cbbOpcoes.SelectedIndex == 2){
                cbbFuncionariosSal.Enabled = true;
                cbbFuncionariosSal.SelectedIndex = 0;

                string[] dados = Salario.((int)cbbSalariosSal.SelectedValue);
                ListViewItem item;

                item = new ListViewItem(dados);
                lstDados.Items.Add(item);
            }
            else
            {
                cbbFuncionariosSal.Enabled = false;
                cbbFuncionariosSal.SelectedIndex = 0;
            }
            //apenas func selecionado
            

        }
    }
}
