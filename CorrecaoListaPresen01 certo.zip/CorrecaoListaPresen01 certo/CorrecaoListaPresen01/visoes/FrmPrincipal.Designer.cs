﻿
namespace CorrecaoListaPresen01.visoes
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnsPrincipal = new System.Windows.Forms.MenuStrip();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCadFuncionario = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCadSalario = new System.Windows.Forms.ToolStripMenuItem();
            this.relatoriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRelGerais = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRelEspecifico = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnsPrincipal
            // 
            this.mnsPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroToolStripMenuItem,
            this.relatoriosToolStripMenuItem,
            this.menuSair});
            this.mnsPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnsPrincipal.Name = "mnsPrincipal";
            this.mnsPrincipal.Size = new System.Drawing.Size(610, 24);
            this.mnsPrincipal.TabIndex = 0;
            this.mnsPrincipal.Text = "menuStrip1";
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuCadFuncionario,
            this.menuCadSalario});
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.cadastroToolStripMenuItem.Text = "Cadastro";
            // 
            // menuCadFuncionario
            // 
            this.menuCadFuncionario.Name = "menuCadFuncionario";
            this.menuCadFuncionario.Size = new System.Drawing.Size(137, 22);
            this.menuCadFuncionario.Text = "Funcionario";
            this.menuCadFuncionario.Click += new System.EventHandler(this.menuCadFuncionario_Click);
            // 
            // menuCadSalario
            // 
            this.menuCadSalario.Name = "menuCadSalario";
            this.menuCadSalario.Size = new System.Drawing.Size(137, 22);
            this.menuCadSalario.Text = "Salario";
            this.menuCadSalario.Click += new System.EventHandler(this.menuCadSalario_Click);
            // 
            // relatoriosToolStripMenuItem
            // 
            this.relatoriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuRelGerais,
            this.menuRelEspecifico});
            this.relatoriosToolStripMenuItem.Name = "relatoriosToolStripMenuItem";
            this.relatoriosToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.relatoriosToolStripMenuItem.Text = "Relatorios";
            // 
            // menuRelGerais
            // 
            this.menuRelGerais.Name = "menuRelGerais";
            this.menuRelGerais.Size = new System.Drawing.Size(180, 22);
            this.menuRelGerais.Text = "Dados funcionários";
            this.menuRelGerais.Click += new System.EventHandler(this.menuRelGerais_Click);
            // 
            // menuRelEspecifico
            // 
            this.menuRelEspecifico.Name = "menuRelEspecifico";
            this.menuRelEspecifico.Size = new System.Drawing.Size(180, 22);
            this.menuRelEspecifico.Text = "Dados salários";
            // 
            // menuSair
            // 
            this.menuSair.Name = "menuSair";
            this.menuSair.Size = new System.Drawing.Size(38, 20);
            this.menuSair.Text = "Sair";
            this.menuSair.Click += new System.EventHandler(this.menuSair_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 325);
            this.ControlBox = false;
            this.Controls.Add(this.mnsPrincipal);
            this.MainMenuStrip = this.mnsPrincipal;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tela Principal";
            this.mnsPrincipal.ResumeLayout(false);
            this.mnsPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnsPrincipal;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuCadFuncionario;
        private System.Windows.Forms.ToolStripMenuItem menuCadSalario;
        private System.Windows.Forms.ToolStripMenuItem relatoriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuRelGerais;
        private System.Windows.Forms.ToolStripMenuItem menuRelEspecifico;
        private System.Windows.Forms.ToolStripMenuItem menuSair;
    }
}