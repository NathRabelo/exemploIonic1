﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using CorrecaoListaPresen01.model;

namespace CorrecaoListaPresen01.visoes
{
    public partial class FrmDadosFuncionarios : Form
    {
        public FrmDadosFuncionarios()
        {
            InitializeComponent();
        }

        private void FrmDadosFuncionarios_Load(object sender, EventArgs e)
        {
            //PREENCHER OS COMBOBOS AUTOMÁTICAMENTE ASSIM QUE O FORMULÁRIO É CARREGADO
            cbbFuncionarios.Enabled = false;
            //O que será exibido no combobox para o usuário
            cbbFuncionarios.DisplayMember = "nome";
            //Qual será o valor daquela seleção do combobox
            cbbFuncionarios.ValueMember = "id";
            //Preencher o combobox
            cbbFuncionarios.DataSource = DadosBD.DadosComboBox();
            cbbFuncionarios.SelectedIndex = 0;
            cbbOpcoes.SelectedIndex = 0;
        }
        private void cbbOpcoes_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Aqui estou limpando todo conteúdo da minha tabela para ficar somente as novas informações
            lstDados.Items.Clear();
            if (cbbOpcoes.SelectedIndex == 1)
            {
                //DADOS DE TODOS OS FUNCIONÁRIOS
                cbbFuncionarios.Enabled = false;
                //Variável auxiliar que irá armazenar todo conteúdo que será exibido na tabela
                List<string[]> dados = DadosBD.DadosFuncionarios();
                //ListView
                /*
                 * Um componente usado para organizar os dados em tabelas
                 * Deixando tudo mais organizado e de fácil entendimento
                 * Prefixo para ele lstNomeDele
                 * Para criar as colunas usa-se a propriedade Columns
                 * Para mostrar as colunas criada deixe a propriedade view como details
                 */

                //Como inserir dados no ListView
                ListViewItem item;
                for (int i = 0; i < dados.Count; i++)
                {
                    item = new ListViewItem(dados[i]);
                    lstDados.Items.Add(item);
                    /*
                     * Os itens devem vir em um vetor de string
                     * Cada posição do vetor é uma coluna do ListView
                     * Eles devem estar na mesma ordem de criação das colunas do ListView
                     * A montagem desse vetor está vindo da classe Funcionario da pasta de controle
                     * A montagem dessa lista de vetores está vindo da classe DadosBD
                     */
                }
            }
            else if (cbbOpcoes.SelectedIndex == 2)
            {
                //DADOS DE UM FUNCIONÁRIO ESPECÍFICO
                cbbFuncionarios.Enabled = true;
                cbbFuncionarios.SelectedIndex = 0;
                
            }
            else
            {
                cbbFuncionarios.Enabled = false;
                cbbFuncionarios.SelectedIndex = 0;
            }

        }

        private void cbbFuncionarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] dados = DadosBD.DadosFuncionarios((int)cbbFuncionarios.SelectedValue);
            ListViewItem item;

            item = new ListViewItem(dados);
            lstDados.Items.Add(item);

        }
    }
}
